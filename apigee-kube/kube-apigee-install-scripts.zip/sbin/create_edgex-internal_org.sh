#!/bin/bash

currDir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

export msvc_org=msvc-internal
export org_name=edgex-internal
environments=(test prod)
export vh_name1=default
export vh_port1=23002
export vh_alias1=10.10.0.5
export vh_name2=secure
export vh_port2=23003
export vh_alias2=10.10.0.5
export isCpsEnabled=true
export isEdgexEnabled=false
export MGMT_HOST=http://localhost:28081
export MP_HOST=http://localhost:28083
export region=dc-1
export pod=gateway
export ADMIN_EMAIL=admin@apigee.com
export ADMIN_PASSWORD=Apigee123

export RING_NAME=emerald
export RING_TYPE=cassandra_ring
export CASS_IP=10.10.0.2

export org_payload='<Organization name="'$org_name'" type="internal"><CustomerName>'$org_name'</CustomerName><Properties><Property name="features.isCpsEnabled">'${isCpsEnabled}'</Property></Properties></Organization>'

$currDir/org_setup.sh regular

#create api product for change server
data='{ "apiResources": [ ], "approvalType": "auto", "description": "Changeserver", "displayName": "Changeserver", "name": "Changeserver", "scopes": [] }'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD $MGMT_HOST/v1/organizations/$org_name/apiproducts -d "$data" -H "Content-type:application/json"

#create api product for snapshot server
data='{ "apiResources": [ ], "approvalType": "auto", "description": "SnapshotServer", "displayName": "SnapshotServer", "name": "SnapshotServer", "scopes": [] }'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD $MGMT_HOST/v1/organizations/$org_name/apiproducts -d "$data" -H "Content-type:application/json"


for env_name in "${environments[@]}"
do
    #create target for apid tracker
    data='{ "host": "10.10.0.16", "isEnabled": true, "name": "target-apidtracker", "orgNameFromPath": { "present": true }, "port": 8081 }'
    curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD $MGMT_HOST/v1/organizations/$org_name/e/$env_name/targetservers -d "$data" -H "Content-type:application/json"

    #create target for change server
    data='{ "host": "10.10.0.15", "isEnabled": true, "name": "target-changeserver", "orgNameFromPath": { "present": true }, "port": 8081 }'
    curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD $MGMT_HOST/v1/organizations/$org_name/e/$env_name/targetservers -d "$data" -H "Content-type:application/json"

    #create target for uap collection
    data='{ "host": "localhost", "isEnabled": true, "name": "target-uapcollection", "orgNameFromPath": { "present": true }, "port": 8080 }'
    curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD $MGMT_HOST/v1/organizations/$org_name/e/$env_name/targetservers -d "$data" -H "Content-type:application/json"

    #create target for snapshot server
    data='{ "host": "10.10.0.14", "isEnabled": true, "name": "target-snapshotserver", "orgNameFromPath": { "present": true }, "port": 8081 }'
    curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD $MGMT_HOST/v1/organizations/$org_name/e/$env_name/targetservers -d "$data" -H "Content-type:application/json"

    #create target for blobservice
    data='{ "host": "localhost", "isEnabled": true, "name": "target-blobservice", "orgNameFromPath": { "present": true }, "port": 8080 }'
    curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD $MGMT_HOST/v1/organizations/$org_name/e/$env_name/targetservers -d "$data" -H "Content-type:application/json"

    #create target for kvm service
    data='{ "host": "'${msvc_org}'-kvm.e2e.apigee.net", "isEnabled": true, "name": "target-kvmservice", "port": 80 }'
    curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD $MGMT_HOST/v1/organizations/$org_name/e/$env_name/targetservers -d "$data" -H "Content-type:application/json"

    #create target for quota service
    data='{ "host": "'${msvc_org}'-quota.e2e.apigee.net", "isEnabled": true, "name": "target-quotaservice", "port": 80 }'
    curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD $MGMT_HOST/v1/organizations/$org_name/e/$env_name/targetservers -d "$data" -H "Content-type:application/json"
done

#TODO: Need latest MP release to support JWT in the proxy - have to wait
#mkdir edgex-internal
#git archive --remote=git@revision.aeip.apigee.net:edgex/edgex-proxies.git HEAD edgex-internal/edgex-oauth/apiproxy > edgex-internal/edgex-oauth.tar
#tar xvf edgex-internal/edgex-oauth.tar
#cd edgex-internal/edgex-oauth
#zip -r edgex-oauth.zip apiproxy
#cd $currDir


# below steps deploy edgex-oauth proxy
echo "############## Importing apiproxy : edgex-oauth ##############"
#curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "${MGMT_HOST}/v1/organizations/$org_name/apis?action=import&name=edgex-oauth" -T edgex-internal/edgex-oauth/edgex-oauth.zip -H "Content-Type: application/octet-stream" -X POST -k
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "${MGMT_HOST}/v1/organizations/$org_name/apis?action=import&name=edgex-oauth" -T $currDir/edgex-oauth.zip -H "Content-Type: application/octet-stream" -X POST -k
echo "############## Importing apiproxy : v1 ##############"
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "${MGMT_HOST}/v1/organizations/$org_name/apis?action=import&name=v1" -T $currDir/v1.zip -H "Content-Type: application/octet-stream" -X POST -k
echo "############## Importing apiproxy : hybrid ##############"
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "${MGMT_HOST}/v1/organizations/$org_name/apis?action=import&name=hybrid" -T $currDir/hybrid.zip -H "Content-Type: application/octet-stream" -X POST -k

echo "############## deploying apiproxy ##############"
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "${MGMT_HOST}/v1/organizations/$org_name/apis/edgex-oauth/revisions/1/deployments?action=deploy&env=prod" -X POST -H "Content-Type: application/octet-stream" -k
echo "############## deploying hybrid ##############"
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "${MGMT_HOST}/v1/organizations/$org_name/apis/hybrid/revisions/1/deployments?action=deploy&env=prod" -X POST -H "Content-Type: application/octet-stream" -k
echo "############## deploying v1 ##############"
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "${MGMT_HOST}/v1/organizations/$org_name/apis/v1/revisions/1/deployments?action=deploy&env=prod" -X POST -H "Content-Type: application/octet-stream" -k


data='{ "emailId" : "alexkhimich+edgex-internal-mgmt-client@google.com",   "firstName" : "edgex-internal-mgmt-client",      "lastName" : "edgex-internal-mgmt-client",      "password" : "#Zmq10Zqt5^Hy9FLM6" }'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD $MGMT_HOST/v1/users -d "$data" -H "Content-type:application/json"

data='<Roles><Role name="developer_apps_only"/></Roles>'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "$MGMT_HOST/v1/o/edgex-internal/userroles" -d "$data" -H "Content-Type: application/xml"
while read -r data; do
    echo ""
    echo "Sending: $data"
    echo ""
    curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "$MGMT_HOST/v1/o/edgex-internal/userroles/developer_apps_only/permissions" -d "$data" -H "Content-Type:application/xml"
done < $currDir/edgex-internal.perms
data='<Roles><Role name="developer_apps_only"/></Roles>'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "$MGMT_HOST/v1/o/edgex-internal/users/alexkhimich+edgex-internal-mgmt-client@google.com/userroles" -d "$data" -H "Content-Type: application/xml"


