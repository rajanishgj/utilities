#!/bin/bash

docker cp /Users/adikancherla/projects/apid/apid_entity_centos apid:/opt/apigee/apigee-apid/bin
docker exec apid sudo mv /opt/apigee/apigee-apid/bin/apid /opt/apigee/apigee-apid/bin/apid_bak
docker exec apid sudo mv /opt/apigee/apigee-apid/bin/apid_entity_centos /opt/apigee/apigee-apid/bin/apid
docker exec apid sudo chmod +x /opt/apigee/apigee-apid/bin/apid
docker exec apid sudo /opt/apigee/apigee-service/bin/apigee-service apigee-apid restart

docker cp $API_PLATFORM_DIR/apigee/zip/target/apigee-zip-1.0.0-*/apigee-zip-1.0.0/lib/. mp:/opt/apigee/edge-gateway/lib
docker cp $API_PLATFORM_DIR/apigee/zip/deploy/source/conf/. mp:/opt/apigee/edge-message-processor/source/conf
docker cp $API_PLATFORM_DIR/apigee/zip/deploy/source/profiles/. mp:/opt/apigee/edge-message-processor/source/profiles
docker exec mp sudo /opt/apigee/apigee-service/bin/apigee-service edge-message-processor restart &

docker cp $API_PLATFORM_DIR/apigee/zip/target/apigee-zip-1.0.0-*/apigee-zip-1.0.0/lib/. apid:/opt/apigee/edge-gateway/lib
docker cp $API_PLATFORM_DIR/apigee/zip/deploy/source/conf/. apid:/opt/apigee/edge-x-hybrid/source/conf
docker cp $API_PLATFORM_DIR/apigee/zip/deploy/source/profiles/. apid:/opt/apigee/edge-x-hybrid/source/profiles
docker exec apid sudo /opt/apigee/apigee-service/bin/apigee-service edge-x-hybrid restart