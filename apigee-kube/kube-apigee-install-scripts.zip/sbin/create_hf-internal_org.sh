#!/bin/bash

#Purpose: create a Hosted Functions enabled org
#Usage: sh create_hosted-functions-test_org.sh
#Exit Status: 0
currDir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
#. "$currDir/../global.sh" || exit 1

export org_name=hf-internal
export vh_name1=default
export vh_port1=23008
export vh_alias1=hf-internal-test.com

export vh_name2=secure
export vh_port2=23009
export vh_alias2=hf-internal-prod.com
export isCpsEnabled=true
export isEdgexEnabled=false
export isEdgeFunctionsEnabled=true
export MGMT_HOST=apigee-mgmt.default.svc.cluster.local:8080
export MP_HOST=apigee-mp.default.svc.cluster.local:8080
export region=dc-1
export pod=gateway
export ADMIN_EMAIL=admin@apigee.com
export ADMIN_PASSWORD=Apigee123

export RING_NAME=emerald
export RING_TYPE=cassandra_ring
export CASS_IP=apigee-cas.default.svc.cluster.local

export org_payload='<Organization name="'$org_name'" type="paid"><CustomerName>'$org_name'</CustomerName><Properties><Property name="features.isCpsEnabled">'${isCpsEnabled}'</Property><Property name="features.isEdgeFunctionsEnabled">'${isEdgeFunctionsEnabled}'</Property></Properties></Organization>'

$currDir/org_setup.sh regular

