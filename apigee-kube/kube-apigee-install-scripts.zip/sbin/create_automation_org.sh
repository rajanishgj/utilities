#!/bin/bash

currDir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

export org_name=AutomationOrganization
export env_name=qa
export vh_name1=default
export vh_port1=24001
export vh_alias1=apigee-rt.default.svc.cluster.local
export vh_name2=secure
export vh_port2=24002
export vh_alias2=apigee-rt.default.svc.cluster.local
export isCpsEnabled=true
export isEdgexEnabled=true
export MGMT_HOST=apigee-mgmt.default.svc.cluster.local:8080
export MP_HOST=apigee-mp.default.svc.cluster.local:8080
export region=dc-1
export pod=gateway
export ADMIN_EMAIL=admin@apigee.com
export ADMIN_PASSWORD=Apigee123

export RING_NAME=emerald
export RING_TYPE=cassandra_ring
export CASS_IP=apigee-cas.default.svc.cluster.local:8080

export PG_RING_NAME=diamond01_pg
export PG_HOST=apigee-ax.default.svc.cluster.local:8080
export PG_PORT=5432

export org_payload='<Organization name="'$org_name'" type="paid"><CustomerName>'$org_name'</CustomerName><Properties><Property name="features.isCpsEnabled">'${isCpsEnabled}'</Property><Property name="features.isEdgexEnabled">'${isEdgexEnabled}'</Property></Properties></Organization>'


#Create customer
data='<Customer><Name>'$org_name'</Name><Id>'$org_name'</Id></Customer>'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -X POST -H 'content-type:application/xml' ${MGMT_HOST}/v1/customers -d "$data"
#Create org
echo "create org : $org_payload "
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -X POST -H 'content-type:application/xml' ${MGMT_HOST}/v1/o -d "$org_payload"

#create env1
data='<Environment name="'$env_name'"/>'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -X POST -H 'content-type:application/xml' ${MGMT_HOST}/v1/o/$org_name/environments -d "$data"

#add pod to org
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -X POST ${MGMT_HOST}/v1/o/$org_name/pods -d "region=${region}&pod=${pod}"

#associate mp
uuid=`curl -s ${MP_HOST}/v1/servers/self/uuid`
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -X POST ${MGMT_HOST}/v1/o/$org_name/e/qa/servers -d "uuid=$uuid&region=${region}&pod=${pod}"

$currDir/enable_cps.sh
$currDir/enable_cps_edgex.sh

data='<VirtualHost name="'$vh_name1'"><Port>'$vh_port1'</Port><HostAliases><HostAlias>'$vh_alias1'</HostAlias></HostAliases></VirtualHost>'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD ${MGMT_HOST}/v1/o/$org_name/e/$env_name/virtualhosts -X POST -d "$data" -H 'content-type:application/xml'

data='<Roles><Role name="sysadmin"/></Roles>'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -X POST -H 'content-type:application/xml' ${MGMT_HOST}/v1/users/${ADMIN_EMAIL}/userroles -d "$data"

data='<Roles><Role name="orgadmin"/></Roles>'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -X POST -H 'content-type:application/xml' ${MGMT_HOST}/v1/o/${org_name}/users/${ADMIN_EMAIL}/userroles -d "$data"

#create apid cluster
data='{"name": "test-cluster1-'$org_name'","description": "test cluster 1"}'
uuid=`curl -s -k -u $ADMIN_EMAIL:$ADMIN_PASSWORD $APID_MGMT_HOST/edgex/apidclusters -d "$data" -H "Content-type:application/json" | jq .id |  tr -d '"' `
#create data scope
data='{"apidCluster": "'$uuid'", "org": "'$org_name'","env": "'$env_name'"}'
curl -v -k -u $ADMIN_EMAIL:$ADMIN_PASSWORD $APID_MGMT_HOST/edgex/datascopes -d "$data" -H "Content-type:application/json"

credentials=`curl -s -k -u $ADMIN_EMAIL:$ADMIN_PASSWORD "$APID_MGMT_HOST/edgex/apidclusters/$uuid/credentials"`
key=`echo $credentials | jq .consumerKey `
secret=`echo $credentials | jq .consumerSecret `

echo "conf_apid_config_apigeesync_cluster_id=$uuid" >> $currDir/apid_config_$org_name.yaml
echo "conf_apid_config_apigeesync_consumer_key=$key" >> $currDir/apid_config_$org_name.yaml
echo "conf_apid_config_apigeesync_consumer_secret=$secret" >> $currDir/apid_config_$org_name.yaml

