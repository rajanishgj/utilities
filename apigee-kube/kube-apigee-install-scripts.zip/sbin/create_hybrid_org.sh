#! /bin/bash
# Launch the hybrid docker containers and wire them together to
# make the planet. The pre-requisite for this to work is to have
# the core container based planet already setup and wired. If
# launching of any of the containers fail, it will exit.

currDir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
. "$(dirname "$0")/../global.sh" || exit 1
export org_name=hybrid
export vh_name1=default
export vh_port1=23006
export vh_alias1=10.10.0.100
export vh_name2=secure
export vh_port2=23007
export vh_alias2=10.10.0.100
export isCpsEnabled=true
export isEdgexEnabled=true
export MGMT_HOST=http://localhost:28081
export APID_MGMT_HOST=https://localhost:28480
export MP_HOST=http://localhost:28083
export region=dc-1
export pod=gateway
export ADMIN_EMAIL=admin@apigee.com
export ADMIN_PASSWORD=Apigee123

export RING_NAME=emerald
export RING_TYPE=cassandra_ring
export CASS_IP=10.10.0.2

export PG_RING_NAME=diamond01_pg
export PG_HOST=10.10.0.12
export PG_PORT=5432

export org_payload='<Organization name="'$org_name'" type="paid"><CustomerName>'$org_name'</CustomerName><Properties><Property name="features.isCpsEnabled">'${isCpsEnabled}'</Property><Property name="features.isEdgexEnabled">'${isEdgexEnabled}'</Property></Properties></Organization>'
AP_SVC=/opt/apigee/apigee-service/bin/apigee-service

$currDir/create_edgex-internal_org.sh || exit 1
$currDir/create_msvc-internal_org.sh || exit 1
docker_exec mgmt sudo "$AP_SVC" apigee-provision enable-ax -f /opt/apigee/edgex-internal.test.cfg \
	|| exit 1
docker_exec mgmt sudo "$AP_SVC" apigee-provision enable-ax -f /opt/apigee/edgex-internal.prod.cfg \
	|| exit 1

$currDir/org_setup.sh edgex || exit 1


echo "############## Importing apiproxy : iloveapis ##############"
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "${MGMT_HOST}/v1/organizations/$org_name/apis?action=import&name=iloveapis" -T iloveapis.zip -H "Content-Type: application/octet-stream" -X POST -k
echo "############## deploying apiproxy : iloveapis ##############"
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "${MGMT_HOST}/v1/organizations/$org_name/apis/iloveapis/revisions/1/deployments?action=deploy&env=prod" -X POST -H "Content-Type: application/octet-stream" -k

#create apid cluster
data='{"name": "test-cluster-1","description": "test cluster 1"}'
uuid=`curl -s -k -u $ADMIN_EMAIL:$ADMIN_PASSWORD $APID_MGMT_HOST/edgex/apidclusters -d "$data" -H "Content-type:application/json" | jq .id |  tr -d '"' `
#create data scope
data='{"apidCluster": "'$uuid'", "org": "'$org_name'","env": "test"}'
curl -s -k -u $ADMIN_EMAIL:$ADMIN_PASSWORD $APID_MGMT_HOST/edgex/datascopes -d "$data" -H "Content-type:application/json"
data='{"apidCluster": "'$uuid'", "org": "'$org_name'","env": "prod"}'
curl -s -k -u $ADMIN_EMAIL:$ADMIN_PASSWORD $APID_MGMT_HOST/edgex/datascopes -d "$data" -H "Content-type:application/json"

credentials=`curl -s -k -u $ADMIN_EMAIL:$ADMIN_PASSWORD "$APID_MGMT_HOST/edgex/apidclusters/$uuid/credentials"`
key=`echo $credentials | jq .consumerKey `
secret=`echo $credentials | jq .consumerSecret `
rm -f apid_config.yaml
echo "apigeesync_cluster_id=$uuid" >> $currDir/apid_config.yaml
echo "apigeesync_consumer_key=$key" >> $currDir/apid_config.yaml
echo "apigeesync_consumer_secret=$secret" >> $currDir/apid_config.yaml

