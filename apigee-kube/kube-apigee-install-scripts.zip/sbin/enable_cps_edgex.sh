#!/bin/bash

echo "Step 1: Create pg Ring"
data='<Ring name="'${PG_RING_NAME}'"><Authenticated>false</Authenticated><Type>postgres_ring</Type></Ring>'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -X POST -H'content-type:application/xml' ${MGMT_HOST}/v1/cps/rings -d "$data"

echo "Step 2: Add server to ring"
data='<Server><InternalHostName>'${PG_HOST}'</InternalHostName><InternalIP>'${PG_HOST}'</InternalIP><ExternalIP>'${PG_HOST}'</ExternalIP><Port>'${PG_PORT}'</Port><DataCenterName>us-east-1</DataCenterName></Server>'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -H'content-type:application/xml' ${MGMT_HOST}/v1/cps/rings/${PG_RING_NAME}/servers/ -d "$data"

echo "Step 3: wire ring to kmsedgex"
data="servicetype=kmsedgex"
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -H 'content-type: application/x-www-form-urlencoded' ${MGMT_HOST}/v1/cps/rings/${PG_RING_NAME}/servicetypes  -d "$data"

echo "Step 4: Provision tenant for an org"
data="<Tenant><Customer>${org_name}</Customer><Product>edge</Product><Organization>${org_name}</Organization></Tenant>"
echo $data
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -H "Content-Type: application/xml" ${MGMT_HOST}/v1/cps/tenants  -d "$data" -H "Accept: application/xml"

echo "Step 5: Get Tenant id for an org"
tenant_id=$(curl -s -u $ADMIN_EMAIL:$ADMIN_PASSWORD -H "Accept: application/json" ${MGMT_HOST}/v1/cps/organizations/${org_name}/products/edge/tenants | jq -r .id)
echo "Tenant id found  : $tenant_id "

echo "Step 6: bind kmsedgex ring to tenant $tenant_id"
data="tenantid=${tenant_id}"
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -H 'content-type: application/x-www-form-urlencoded' ${MGMT_HOST}/v1/cps/rings/${PG_RING_NAME}/servicetypes/kmsedgex/tenants  -d "$data"

echo "Completed Edgex PG wiring for ${org_name} with tenant_id : ${tenant_id}"