#!/bin/bash

base=/opt/apigee/edge-gateway/lib

[[ ! -z "$3" ]] && echo "Executing 'docker cp $1 $3:$base/$2'" && docker cp $1 $3:$base/$2
[[ ! -z "$4" ]] && echo "Executing 'docker cp $1 $4:$base/$2'" && docker cp $1 $4:$base/$2
[[ ! -z "$5" ]] && echo "Executing 'docker cp $1 $5:$base/$2'" && docker cp $1 $5:$base/$2
[[ ! -z "$6" ]] && echo "Executing 'docker cp $1 $6:$base/$2'" && docker cp $1 $6:$base/$2
[[ ! -z "$7" ]] && echo "Executing 'docker cp $1 $7:$base/$2'" && docker cp $1 $7:$base/$2
[[ ! -z "$8" ]] && echo "Executing 'docker cp $1 $8:$base/$2'" && docker cp $1 $8:$base/$2


