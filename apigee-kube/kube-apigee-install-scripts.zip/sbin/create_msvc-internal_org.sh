#!/bin/bash

currDir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

export org_name=msvc-internal
export vh_name1=default
export vh_port1=23004
export vh_alias1=10.10.0.5
export vh_name2=secure
export vh_port2=23005
export vh_alias2=10.10.0.5
export isCpsEnabled=true
export isEdgexEnabled=false
export MGMT_HOST=http://localhost:28081
export MP_HOST=http://localhost:28083
export region=dc-1
export pod=gateway
export ADMIN_EMAIL=admin@apigee.com
export ADMIN_PASSWORD=Apigee123

export RING_NAME=emerald
export RING_TYPE=cassandra_ring
export CASS_IP=10.10.0.2

export org_payload='<Organization name="'$org_name'" type="internal"><CustomerName>'$org_name'</CustomerName><Properties><Property name="features.isCpsEnabled">'${isCpsEnabled}'</Property></Properties></Organization>'

$currDir/org_setup.sh regular

echo "############## Importing apiproxy : microservice ##############"
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "${MGMT_HOST}/v1/organizations/$org_name/apis?action=import&name=microservice" -T $currDir/microservice.zip -H "Content-Type: application/octet-stream" -X POST -k

echo "############## deploying microservice ##############"
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "${MGMT_HOST}/v1/organizations/$org_name/apis/microservice/revisions/1/deployments?action=deploy&env=test" -X POST -H "Content-Type: application/octet-stream" -k
