#!/bin/bash

currDir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

export org_name=cps
export vh_name1=default
export vh_port1=23008
export vh_alias1=cps-test.com
export vh_name2=secure
export vh_port2=23009
export vh_alias2=cps-prod.com
export isCpsEnabled=true
export isEdgexEnabled=false
export MGMT_HOST=apigee-mgmt.default.svc.cluster.local:8080
export MP_HOST=apigee-mp.default.svc.cluster.local:8080
export region=dc-1
export pod=gateway
export ADMIN_EMAIL=admin@apigee.com
export ADMIN_PASSWORD=Apigee123

export RING_NAME=emerald
export RING_TYPE=cassandra_ring
export CASS_IP=apigee-cas.default.svc.cluster.local

export org_payload='<Organization name="'$org_name'" type="paid"><CustomerName>'$org_name'</CustomerName><Properties><Property name="features.isCpsEnabled">'${isCpsEnabled}'</Property></Properties></Organization>'

$currDir/org_setup.sh regular


echo "############## Importing apiproxy : iloveapis ##############"
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "${MGMT_HOST}/v1/organizations/$org_name/apis?action=import&name=iloveapis" -T $currDir/iloveapis.zip -H "Content-Type: application/octet-stream" -X POST -k
echo "############## deploying apiproxy : iloveapis ##############"
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "${MGMT_HOST}/v1/organizations/$org_name/apis/iloveapis/revisions/1/deployments?action=deploy&env=prod" -X POST -H "Content-Type: application/octet-stream" -k

