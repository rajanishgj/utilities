#!/bin/bash
currDir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

#Create customer
data='<Customer><Name>'$org_name'</Name><Id>'$org_name'</Id></Customer>'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -X POST -H 'content-type:application/xml' ${MGMT_HOST}/v1/customers -d "$data"
#Create org
echo "create org : $org_payload "
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -X POST -H 'content-type:application/xml' ${MGMT_HOST}/v1/o -d "$org_payload"

# This step needs to run before the creation of the environments.  See the
# change below for more details.
# https://revision.aeip.apigee.net/4G/api_platform/commit/8a1143b91712056bfefecc8dafc2fc0ef5f81171
if [ "$1" == "edgex" ];
then
    echo "Enabling edgex org"
    $currDir/enable_cps.sh
    $currDir/enable_cps_edgex.sh
else
    echo "Enabling regular org"
    $currDir/enable_cps.sh
fi

#create env1
data='<Environment name="test"/>'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -X POST -H 'content-type:application/xml' ${MGMT_HOST}/v1/o/$org_name/environments -d "$data"

#create env2
data='<Environment name="prod"/>'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -X POST -H 'content-type:application/xml' ${MGMT_HOST}/v1/o/$org_name/environments -d "$data"
#if [ "$1" != "edgex" ];
#then
    #add pod to org
    curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -X POST ${MGMT_HOST}/v1/o/$org_name/pods -d "region=${region}&pod=${pod}"

    #associate mp
    uuid=`curl -s ${MP_HOST}/v1/servers/self/uuid`
    curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -X POST ${MGMT_HOST}/v1/o/$org_name/e/test/servers -d "uuid=$uuid&region=${region}&pod=${pod}"
    curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -X POST ${MGMT_HOST}/v1/o/$org_name/e/prod/servers -d "uuid=$uuid&region=${region}&pod=${pod}"
#fi

#create vh
data='<VirtualHost name="'$vh_name1'"><Port>'$vh_port1'</Port><HostAliases><HostAlias>'$vh_alias1'</HostAlias></HostAliases></VirtualHost>'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD ${MGMT_HOST}/v1/o/$org_name/e/prod/virtualhosts -X POST -d "$data" -H 'content-type:application/xml'

data='<VirtualHost name="'$vh_name1'"><Port>'$vh_port1'</Port><HostAliases><HostAlias>'$vh_alias1'</HostAlias></HostAliases></VirtualHost>'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD ${MGMT_HOST}/v1/o/$org_name/e/test/virtualhosts -X POST -d "$data" -H 'content-type:application/xml'

data='<VirtualHost name="'$vh_name2'"><Port>'$vh_port2'</Port><HostAliases><HostAlias>'$vh_alias2'</HostAlias></HostAliases></VirtualHost>'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD ${MGMT_HOST}/v1/o/$org_name/e/prod/virtualhosts -X POST -d "$data" -H 'content-type:application/xml'

data='<VirtualHost name="'$vh_name2'"><Port>'$vh_port2'</Port><HostAliases><HostAlias>'$vh_alias2'</HostAlias></HostAliases></VirtualHost>'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD ${MGMT_HOST}/v1/o/$org_name/e/test/virtualhosts -X POST -d "$data" -H 'content-type:application/xml'

data='<Roles><Role name="sysadmin"/></Roles>'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -X POST -H 'content-type:application/xml' ${MGMT_HOST}/v1/users/${ADMIN_EMAIL}/userroles -d "$data"

data='<Roles><Role name="orgadmin"/></Roles>'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -X POST -H 'content-type:application/xml' ${MGMT_HOST}/v1/o/${org_name}/users/${ADMIN_EMAIL}/userroles -d "$data"


echo "creating api product"
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD ${MGMT_HOST}/v1/organizations/$org_name/apiproducts -d "<ApiProduct name=\"test_api_product\">
<DisplayName>test api product</DisplayName>
<ApprovalType>auto</ApprovalType>
<ApiResources>
   <ApiResource>/**</ApiResource>
</ApiResources>
<Scopes>
  <Scope>A</Scope>
  <Scope>B</Scope>
  <Scope>C</Scope>
</Scopes>
</ApiProduct>" -X POST -H "Content-Type: application/xml"

echo "creating developer"
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD ${MGMT_HOST}/v1/organizations/$org_name/developers -d "<Developer>
  <Email>test@apigee.com</Email>
  <FirstName>Woodre</FirstName>
  <LastName>Wilson</LastName>
  <UserName>wilson</UserName>
  <Attributes>
        <Attribute>
           <Name>region</Name>
           <Value>north</Value>
        </Attribute>
    </Attributes>
</Developer>" -X POST -H "Content-Type: application/xml"

echo "creating dev app"
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD ${MGMT_HOST}/v1/organizations/$org_name/developers/test@apigee.com/apps -d "<App name=\"test_app\">
<AccessType>read</AccessType>
<CallbackUrl>http://www.apigee.com</CallbackUrl>
<ApiProducts>
<ApiProduct>test_api_product</ApiProduct>
</ApiProducts>
</App>" -X POST -H "Content-Type: application/xml"
