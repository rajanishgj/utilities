#!/bin/bash

echo "Step 1: Create Ring"
data='<Ring name="'${RING_NAME}'"> <Type>'${RING_TYPE}'</Type></Ring>'
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -X POST -H'content-type:application/xml' ${MGMT_HOST}/v1/cps/rings -d "$data"

echo "Step 2: Add server to ring" 
CASS_IP_OR_HOST=$( echo ${CASS_IP} | grep "apigee-cas" )
if [[ -z $CASS_IP_OR_HOST ]] ; then
   data='<Server>  <InternalHostName>'${CASS_IP}'</InternalHostName><InternalIP>'${CASS_IP}'</InternalIP><Port>9042</Port><DataCenterName>datacenter1</DataCenterName></Server>'
else
data='<Server>  <InternalHostName>'${CASS_IP}'</InternalHostName><Port>9042</Port><DataCenterName>datacenter1</DataCenterName></Server>'
fi
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -H'content-type:application/xml' ${MGMT_HOST}/v1/cps/rings/${RING_NAME}/servers/ -d "$data"

for t in {kvm,cache,quota,kms}
do
 echo "Step 3: wire ring to $t"
 data="servicetype=$t"
 curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -H 'content-type: application/x-www-form-urlencoded' ${MGMT_HOST}/v1/cps/rings/${RING_NAME}/servicetypes  -d "$data"
done

#echo "Step 4: enable cps for an org"
#data='{   "name": "'${org_name}'",  "customerName": "'${org_name}'"  ,"properties": {"property": [ {"name": "features.isCpsEnabled","value":"true"},{                "name": "features.isEdgexEnabled",                "value": "true"            }          ]} , "type" : "internal" }'

#curl -s -H "Content-Type: application/json" ${MGMT_HOST}/v1/o/${org_name} -d "$data"

echo "Step 5: Provision tenant for an org"
data="<Tenant><Customer>${org_name}</Customer><Product>edge</Product><Organization>${org_name}</Organization></Tenant>"
echo $data 
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -H "Content-Type: application/xml" ${MGMT_HOST}/v1/cps/tenants  -d "$data" -H "Accept: application/xml"

echo "Get Tenant id for an org"
tenant_id=$(curl -s -u $ADMIN_EMAIL:$ADMIN_PASSWORD -H "Accept: application/json" ${MGMT_HOST}/v1/cps/organizations/${org_name}/products/edge/tenants | jq -r .id)
echo "Tenant id found  : $tenant_id "

for t in {kvm,cache,quota,kms}
do
 echo "Step 6: bind $t ring to tenant $tenant_id"
 data="tenantid=${tenant_id}"
 curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -H 'content-type: application/x-www-form-urlencoded' ${MGMT_HOST}/v1/cps/rings/${RING_NAME}/servicetypes/${t}/tenants  -d "$data"
done

echo "Step 7: Create Perses Keyspace"
data="<PersesKeyspace><NetworkTopology><DataCenterOption><DataCenter>dc-1</DataCenter><ReplicationCount>1</ReplicationCount></DataCenterOption></NetworkTopology></PersesKeyspace>"
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -H "Content-Type: application/xml" ${MGMT_HOST}/v1/cps/rings/${RING_NAME}/servicetypes/kvm/keyspaces/perses  -d "$data" -H "Accept: application/json"

for t in {kvm,cache,quota,kms}
do
 echo "Step 8: Provision Keyspace for $t"
 data="<Keyspace><TenantId>${tenant_id}</TenantId> <KeyspaceType>prod</KeyspaceType><NetworkTopology><DataCenterOption><DataCenter>dc-1</DataCenter> <ReplicationCount>1</ReplicationCount></DataCenterOption> </NetworkTopology>   <ColumnFamilyCreationDelayInSeconds>2</ColumnFamilyCreationDelayInSeconds></Keyspace>"
 curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD -H 'content-type: application/xml' ${MGMT_HOST}/v1/cps/rings/${RING_NAME}/servicetypes/${t}/keyspaces  -d "$data"
done

echo "Completed CPS setup for ${org_name} with tenant_id : ${tenant_id}"
