#!/bin/bash

currDir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

export org_name=hybrid
export env_name=test
export MGMT_HOST=http://localhost:28081
export ADMIN_EMAIL=admin@apigee.com
export ADMIN_PASSWORD=Apigee123

#delete microservice proxy
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "${MGMT_HOST}/v1/organizations/msvc-internal/e/test/apis/microservice/revisions/1/deployments" -X DELETE -ka
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "${MGMT_HOST}/v1/organizations/msvc-internal/apis/microservice" -X DELETE -k


echo "############## Importing apiproxy : microservice ##############"
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "${MGMT_HOST}/v1/organizations/msvc-internal/apis?action=import&name=microservice" -T $currDir/../proxies/microservice.zip -H "Content-Type: application/octet-stream" -X POST -k

echo "############## deploying microservice ##############"
curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "${MGMT_HOST}/v1/organizations/msvc-internal/apis/microservice/revisions/1/deployments?action=deploy&env=test" -X POST -H "Content-Type: application/octet-stream" -k

files=$(find $currDir/../proxies/oauth -type f -iname '*.zip')
for file in $files
do
    echo $file
    filename=$(basename $file)
    api_name=$(echo "${filename%.*}")
    echo "############## Importing $api_name ##############"
    curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "${MGMT_HOST}/v1/organizations/$org_name/apis?action=import&name=$api_name" -T $file -H "Content-Type: application/octet-stream" -X POST -k

    echo "############## Deploying $api_name ##############"
    curl -v -u $ADMIN_EMAIL:$ADMIN_PASSWORD "${MGMT_HOST}/v1/organizations/$org_name/apis/$api_name/revisions/1/deployments?action=deploy&env=$env_name" -X POST -H "Content-Type: application/octet-stream" -k
done