#!/bin/bash
PROGDIR=$(dirname "$0")
planet_filter='-l planet=apigee-dev'

echo "deleting services with filter "${planet_filter}""
kubectl delete services "${planet_filter}"

echo "deleting deployments with filter "${planet_filter}""
kubectl delete deployments "${planet_filter}"

echo "`date` : wait 10s"
sleep 10

echo "create data components"
kubectl create -f "${PROGDIR}"/../kube-service-apigee-data.yaml

echo "`date` : wait 30s for data pods to be up. FIXME : to check component status instead of random wait"
sleep 30

echo "create services, next step expects services to be up"
kubectl create -f "${PROGDIR}"/../kube-service-apigee-service.yaml
# kubectl create -f "${PROGDIR}"/../kube-service-apigee-istio.yaml

echo "`date` : wait 60s for services to be up. FIXME : to check component status instead of random wait"
sleep 60
kubectl get pods
echo "create ax components"
kubectl create -f "${PROGDIR}"/../kube-service-apigee-ax.yaml


echo "`date` : wait 60s for services to be up. FIXME : to check component status instead of random wait"
sleep 60
kubectl get pods
echo "create mgmt components"
kubectl create -f "${PROGDIR}"/../kube-service-apigee-mgmt.yaml

echo "`date` : wait 300s and then create test orgs"
sleep 300

kubectl get pods

echo "create runtime components"
kubectl create -f "${PROGDIR}"/../kube-service-apigee-runtime.yaml

kubectl get pods

echo "`date` : wait 60s for runtime pods to be up. FIXME : to check component status instead of random wait"
sleep 60

kubectl get pods

echo "org provisioning : zip sbin, mkdir in mgmt, cp sbin.zip to mgmt, run create_cps_org script"
#zip -rj sbin.zip "${PROGDIR}"/../sbin
MGMT_POD_NAME=$(kubectl get pods -l "app=apigee-mgmt" -o go-template --template '{{range .items}}{{.metadata.name}}{{"\n"}}{{end}}')
#kubectl exec "${MGMT_POD_NAME}" -- mkdir -p /dp
#kubectl cp sbin.zip "${MGMT_POD_NAME}":/dp/
#kubectl exec "${MGMT_POD_NAME}" -- unzip -oj /dp/sbin.zip -d /dp/


echo "creating non cps org"
# hack to avoid rebuilding image
# kubectl cp "${PROGDIR}"/../opt/apigee/org.cfg "${MGMT_POD_NAME}":/opt/apigee/org.cfg

AP_SVC=/opt/apigee/apigee-service/bin/apigee-service
kubectl exec "${MGMT_POD_NAME}" -- "$AP_SVC" apigee-provision setup-org -f /opt/apigee/org.cfg || exit 1

echo "creating cps org"
kubectl exec "${MGMT_POD_NAME}" -- /opt/apigee/sbin/create_cps_org.sh || exit 1

echo "Test runtime call now - curl      http://apigee-rt.default.svc.cluster.local:23008/iloveapis"
ilapis_resp=$(kubectl exec "${MGMT_POD_NAME}" -- curl  http://apigee-rt.default.svc.cluster.local:23008/iloveapis -w "%{http_code}" -H "Host: cps-test.com" -s -o /dev/null && echo $http_code)

if [[ "${ilapis_resp}" != "200" ]] ; then
    echo "i love apis call on cps org failed with response code : $ilapis_resp"
else
    echo "i love apis call on cps org succeeded"
fi

echo "creating hf-internal org"
kubectl exec "${MGMT_POD_NAME}" -- /opt/apigee/sbin/create_hf-internal_org.sh || exit 1

#
# per http://docs.apigee.com/private-cloud/latest/creating-organization-environment-and-virtual-host
#
ORG_LIST='/opt/apigee/cps.prod.cfg /opt/apigee/cps.test.cfg /opt/apigee/hf-internal.prod.cfg /opt/apigee/hf-internal.test.cfg'
echo "enable ax for $ORG_LIST"
for i in $ORG_LIST; do
	kubectl exec "${MGMT_POD_NAME}" -- "$AP_SVC" apigee-provision enable-ax -f $i || exit 1
done